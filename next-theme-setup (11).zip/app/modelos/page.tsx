import { ModelsGallery } from "@/components/models/models-gallery"

export default function ModelsPage() {
  return <ModelsGallery />
}
