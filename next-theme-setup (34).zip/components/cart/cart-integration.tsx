"use client"

import { ColorfulFloatingCart } from "./colorful-floating-cart"

export function CartIntegration() {
  return <ColorfulFloatingCart />
}
