import { ProductionConfigComplete } from "@/components/admin/production-config-complete"

export default function StripeFinalPage() {
  return <ProductionConfigComplete />
}
