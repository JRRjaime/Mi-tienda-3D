import { BarChart3 } from "lucide-react"
import Link from "next/link"

export function GlobalHeader() {
  return (
    <header className="bg-background border-b">
