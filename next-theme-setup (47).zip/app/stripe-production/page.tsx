import { ProductionStripeSetup } from "@/components/admin/production-stripe-setup"

export default function StripeProductionPage() {
  return <ProductionStripeSetup />
}
