import { StripeQuickSetup } from "@/components/admin/stripe-quick-setup"

export default function StripeSetupPage() {
  return <StripeQuickSetup />
}
