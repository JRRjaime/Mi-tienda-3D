import { StripeConfigChecker } from "@/components/admin/stripe-config-checker"

export default function StripeConfigPage() {
  return <StripeConfigChecker />
}
